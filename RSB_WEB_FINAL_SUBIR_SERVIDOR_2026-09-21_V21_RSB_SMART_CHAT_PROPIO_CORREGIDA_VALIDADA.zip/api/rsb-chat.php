<?php

/* RSB V21 deterministic same-origin chat endpoint. No external services. */

function rsb_json_response($status, $payload) {
    if (PHP_SAPI !== 'cli') {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('X-Content-Type-Options: nosniff');
    }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function rsb_load_json($path) {
    $raw = @file_get_contents($path);
    if ($raw === false) {
        return null;
    }
    $data = json_decode($raw, true);
    return is_array($data) ? $data : null;
}

function rsb_strlen($text) {
    return function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : strlen($text);
}

function rsb_lower($text) {
    return function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text);
}

function rsb_normalize($text, $aliases) {
    if (class_exists('Normalizer')) {
        $normalized = Normalizer::normalize($text, Normalizer::FORM_D);
        if (is_string($normalized)) {
            $text = $normalized;
            $text = preg_replace('/\p{Mn}+/u', '', $text);
        }
    }
    $text = rsb_lower($text);
    $map = [
        'á'=>'a','à'=>'a','ä'=>'a','â'=>'a','ã'=>'a','å'=>'a','æ'=>'ae',
        'é'=>'e','è'=>'e','ë'=>'e','ê'=>'e','í'=>'i','ì'=>'i','ï'=>'i','î'=>'i',
        'ó'=>'o','ò'=>'o','ö'=>'o','ô'=>'o','õ'=>'o','ø'=>'o','ú'=>'u','ù'=>'u','ü'=>'u','û'=>'u',
        'ñ'=>'n','ç'=>'c','ß'=>'ss','ł'=>'l','ś'=>'s','ź'=>'z','ż'=>'z','ć'=>'c','ń'=>'n','ą'=>'a','ę'=>'e',
        'ř'=>'r','š'=>'s','ž'=>'z','ý'=>'y','č'=>'c','ď'=>'d','ť'=>'t'
    ];
    $text = strtr($text, $map);
    $text = preg_replace('/[^\p{L}\p{N}\s\.\,\+\-]/u', ' ', $text);
    $text = preg_replace('/\s+/u', ' ', trim($text));
    if (is_array($aliases)) {
        foreach ($aliases as $from => $to) {
            $fromN = rsb_lower($from);
            $toN = rsb_lower($to);
            if ($fromN !== '' && strpos($text, $fromN) !== false) {
                $text = str_replace($fromN, $toN, $text);
            }
        }
    }
    return $text;
}

function rsb_term_match($text, $term) {
    $term = trim($term);
    if ($term === '') {
        return false;
    }
    $quoted = preg_quote($term, '/');
    return preg_match('/(?<![\p{L}\p{N}])' . $quoted . '(?![\p{L}\p{N}])/u', $text) === 1;
}

function rsb_language($hint, $config) {
    $hint = rsb_lower((string)$hint);
    if (strpos($hint, '-') !== false) {
        $hint = explode('-', $hint, 2)[0];
    }
    return in_array($hint, $config['languages'], true) ? $hint : 'en';
}

function rsb_extract_product($text, $lang, $config) {
    $products = isset($config['synonyms']['products']) ? $config['synonyms']['products'] : [];
    $bestProduct = null;
    $bestLength = -1;
    foreach ($products as $product => $sets) {
        $terms = [];
        if (isset($sets[$lang])) {
            $terms = array_merge($terms, $sets[$lang]);
        }
        if ($lang !== 'en' && isset($sets['en'])) {
            $terms = array_merge($terms, $sets['en']);
        }
        foreach ($terms as $term) {
            $tn = rsb_normalize($term, []);
            if (rsb_term_match($text, $tn)) {
                $len = rsb_strlen($tn);
                if ($len > $bestLength) {
                    $bestLength = $len;
                    $bestProduct = $product;
                }
            }
        }
    }
    return $bestProduct;
}

function rsb_extract_duration($text) {
    $phrases = [
        'full day' => ['full day','dia completo','journée complete','journee complete','giornata intera','ganzer tag','hele dag','dia inteiro','dia sencer','heldag','caly dzien'],
        '24 hours' => ['24h','24 h','24 hours','24 horas','24 heures','24 ore','24 stunden','24 uur','24 timmar','24 godziny','24 godzin'],
        'extra day' => ['extra day','dia extra','jour supplementaire','giorno extra','zusatztag','extra dag','dia adicional','dia extra','extra dag','dodatkowy dzien'],
        '2 days' => ['2 days','2 dias','2 jours','2 giorni','2 tage','2 dagen','2 dies','2 dagar','2 dni'],
        '3 days' => ['3 days','3 dias','3 jours','3 giorni','3 tage','3 dagen','3 dies','3 dagar','3 dni']
    ];
    foreach ($phrases as $canon => $terms) {
        foreach ($terms as $term) {
            if (rsb_term_match($text, rsb_normalize($term, []))) {
                return $canon;
            }
        }
    }
    if (preg_match('/\b(1|2|3|4)\s*(h|hr|hrs|hour|hours|hora|horas|hores|heure|heures|ore|stunde|stunden|uur|uren|timme|timmar|godzina|godziny|godzin)\b/u', $text, $m)) {
        return $m[1] . ' hour' . ($m[1] === '1' ? '' : 's');
    }
    return null;
}

function rsb_detect_intents($text, $lang, $config, $product, $duration, $context) {
    $hits = [];
    foreach ($config['intents'] as $name => $def) {
        $sets = isset($def['terms']) ? $def['terms'] : [];
        $terms = isset($sets[$lang]) ? $sets[$lang] : [];
        if ($lang !== 'en' && isset($sets['en'])) {
            $terms = array_merge($terms, $sets['en']);
        }
        foreach ($terms as $term) {
            if (rsb_term_match($text, rsb_normalize($term, []))) {
                $hits[$name] = true;
                break;
            }
        }
    }
    if (isset($hits['PRICE']) && $duration !== null) {
        $hits['PRICE_DURATION'] = true;
    }
    if (preg_match('/\b50\s*cc\b/u', $text)) {
        $hits['SCOOTER_50'] = true;
        if ($product === null) $product = 'scooter';
    }
    if (preg_match('/\b125\s*cc\b/u', $text)) {
        $hits['SCOOTER_125'] = true;
        if ($product === null) $product = 'scooter';
    }
    $follow = false;
    if ($product === null && isset($context['product']) && is_string($context['product'])) {
        if ($duration !== null || isset($hits['DEPOSIT']) || isset($hits['PROTECTIONS']) || isset($hits['STORAGE']) || isset($hits['PRICE']) || isset($hits['ID_DOCUMENT']) || isset($hits['LICENSE']) || isset($hits['PAYMENT']) || isset($hits['RETURN'])) {
            $follow = true;
            $product = $context['product'];
            $hits['FOLLOW_UP'] = true;
            if (!isset($hits['PRICE']) && $duration !== null && isset($context['last_intents']) && is_array($context['last_intents']) && (in_array('PRICE', $context['last_intents'], true) || in_array('PRICE_DURATION', $context['last_intents'], true))) {
                $hits['PRICE'] = true;
            }
            if (isset($hits['PRICE']) && $duration !== null) {
                $hits['PRICE_DURATION'] = true;
            }
        }
    }
    $meaningful = array_diff(array_keys($hits), ['FOLLOW_UP','SCOOTER_50','SCOOTER_125']);
    if (in_array('PRICE_DURATION', $meaningful, true)) {
        $meaningful = array_values(array_diff($meaningful, ['PRICE']));
    }
    if (count($meaningful) > 1) {
        $hits['MULTI_INTENT'] = true;
    }
    if (!$hits && $product !== null) {
        $hits['PRODUCTS'] = true;
    }
    if (!$hits) {
        $hits['OUT_OF_SCOPE'] = true;
    }
    return [array_keys($hits), $product, $follow];
}

function rsb_service_id_for_product($product) {
    $map = [
        'scooter'=>'scooter-rental-barcelona',
        'inline_skates'=>'inline-skates-rental-barcelona',
        'bike'=>'bike-rental-barcelona',
        'quad_skates'=>'roller-skates-rental-barcelona',
        'skateboard'=>'skateboard-rental-barcelona',
        'longboard'=>'longboard-rental-barcelona'
    ];
    return isset($map[$product]) ? $map[$product] : null;
}

function rsb_find_service($data, $id) {
    if (!$id || !isset($data['services']) || !is_array($data['services'])) {
        return null;
    }
    foreach ($data['services'] as $service) {
        if (isset($service['id']) && $service['id'] === $id) {
            return $service;
        }
    }
    return null;
}

function rsb_labels($lang) {
    $all = [
        'en'=>['published'=>'Published','from'=>'from','hours'=>'Opening hours','location'=>'RSB is located at','near'=>'Near','deposit_none'=>'No deposit is required for this rental.','deposit_scooter'=>'A refundable security deposit applies to motor scooter rentals; the amount is not specified in the local source files.','id'=>'A valid ID may be required. Contact RSB to confirm the document needed for your rental.','storage'=>'Free luggage storage is available for all rental services.','products'=>'RSB offers','contact'=>'Contact RSB','children'=>'Children’s bikes are available. For other child-specific requirements, contact RSB.','scooters'=>'RSB rents petrol 50cc and 125cc motor scooters. Electric kick scooters and e-bikes are not listed as rental services.','durations'=>'Published rental periods','included'=>'Included','today'=>'Today'],
        'es'=>['published'=>'Publicado','from'=>'desde','hours'=>'Horario','location'=>'RSB está en','near'=>'Cerca de','deposit_none'=>'No se requiere fianza para este alquiler.','deposit_scooter'=>'Se aplica una fianza reembolsable a los scooters de motor; el importe no está especificado en las fuentes locales.','id'=>'Puede requerirse una identificación válida. Contacta con RSB para confirmar el documento necesario para tu alquiler.','storage'=>'Hay consigna gratuita de equipaje para todos los servicios de alquiler.','products'=>'RSB ofrece','contact'=>'Contacto RSB','children'=>'Hay bicicletas para niños. Para otros requisitos específicos de menores, contacta con RSB.','scooters'=>'RSB alquila scooters de gasolina de 50cc y 125cc. Los patinetes eléctricos y e-bikes no figuran como servicios de alquiler.','durations'=>'Periodos de alquiler publicados','included'=>'Incluido','today'=>'Hoy'],
        'fr'=>['published'=>'Publié','from'=>'à partir de','hours'=>'Horaires','location'=>'RSB se trouve au','near'=>'Près de','deposit_none'=>'Aucune caution n’est requise pour cette location.','deposit_scooter'=>'Une caution remboursable s’applique aux scooters motorisés ; son montant n’est pas indiqué dans les sources locales.','id'=>'Une pièce d’identité valide peut être requise. Contactez RSB pour confirmer le document nécessaire.','storage'=>'Une consigne gratuite est disponible pour tous les services de location.','products'=>'RSB propose','contact'=>'Contact RSB','children'=>'Des vélos pour enfants sont disponibles. Pour les autres besoins spécifiques aux enfants, contactez RSB.','scooters'=>'RSB loue des scooters essence 50cc et 125cc. Les trottinettes électriques et vélos électriques ne sont pas listés.','durations'=>'Durées de location publiées','included'=>'Inclus','today'=>'Aujourd’hui'],
        'it'=>['published'=>'Pubblicato','from'=>'da','hours'=>'Orari','location'=>'RSB si trova in','near'=>'Vicino a','deposit_none'=>'Non è richiesto alcun deposito per questo noleggio.','deposit_scooter'=>'Per gli scooter a motore si applica un deposito cauzionale rimborsabile; l’importo non è specificato nelle fonti locali.','id'=>'Può essere richiesto un documento d’identità valido. Contatta RSB per confermare il documento necessario.','storage'=>'Il deposito bagagli gratuito è disponibile per tutti i servizi di noleggio.','products'=>'RSB offre','contact'=>'Contatto RSB','children'=>'Sono disponibili biciclette per bambini. Per altri requisiti specifici, contatta RSB.','scooters'=>'RSB noleggia scooter a benzina 50cc e 125cc. Monopattini elettrici ed e-bike non sono elencati.','durations'=>'Periodi di noleggio pubblicati','included'=>'Incluso','today'=>'Oggi'],
        'de'=>['published'=>'Veröffentlicht','from'=>'ab','hours'=>'Öffnungszeiten','location'=>'RSB befindet sich in','near'=>'In der Nähe von','deposit_none'=>'Für diese Miete ist keine Kaution erforderlich.','deposit_scooter'=>'Für Motorroller gilt eine rückzahlbare Kaution; die Höhe ist in den lokalen Quellen nicht angegeben.','id'=>'Ein gültiger Ausweis kann erforderlich sein. Bitte RSB kontaktieren, um das benötigte Dokument zu bestätigen.','storage'=>'Für alle Mietservices ist kostenlose Gepäckaufbewahrung verfügbar.','products'=>'RSB bietet','contact'=>'Kontakt RSB','children'=>'Kinderfahrräder sind verfügbar. Für andere kinderspezifische Anforderungen bitte RSB kontaktieren.','scooters'=>'RSB vermietet benzinbetriebene 50cc- und 125cc-Motorroller. E-Scooter und E-Bikes sind nicht aufgeführt.','durations'=>'Veröffentlichte Mietzeiträume','included'=>'Inklusive','today'=>'Heute'],
        'nl'=>['published'=>'Gepubliceerd','from'=>'vanaf','hours'=>'Openingstijden','location'=>'RSB is gevestigd op','near'=>'Dicht bij','deposit_none'=>'Voor deze huur is geen borg vereist.','deposit_scooter'=>'Voor motorscooters geldt een terugbetaalbare borg; het bedrag staat niet in de lokale bronnen.','id'=>'Een geldig identiteitsbewijs kan vereist zijn. Neem contact op met RSB om het benodigde document te bevestigen.','storage'=>'Gratis bagageopslag is beschikbaar voor alle verhuurdiensten.','products'=>'RSB verhuurt','contact'=>'Contact RSB','children'=>'Kinderfietsen zijn beschikbaar. Neem voor andere kind-specifieke eisen contact op met RSB.','scooters'=>'RSB verhuurt benzine 50cc- en 125cc-motorscooters. Elektrische steps en e-bikes staan niet als verhuurdienst vermeld.','durations'=>'Gepubliceerde huurperiodes','included'=>'Inbegrepen','today'=>'Vandaag'],
        'pt'=>['published'=>'Publicado','from'=>'desde','hours'=>'Horário','location'=>'A RSB fica em','near'=>'Perto de','deposit_none'=>'Não é exigida caução para este aluguer.','deposit_scooter'=>'Aplica-se uma caução reembolsável aos scooters a motor; o valor não está especificado nas fontes locais.','id'=>'Pode ser exigida uma identificação válida. Contacte a RSB para confirmar o documento necessário.','storage'=>'Existe armazenamento gratuito de bagagem para todos os serviços de aluguer.','products'=>'A RSB oferece','contact'=>'Contacto RSB','children'=>'Existem bicicletas para crianças. Para outros requisitos específicos, contacte a RSB.','scooters'=>'A RSB aluga scooters a gasolina de 50cc e 125cc. Trotinetes elétricas e e-bikes não constam dos serviços.','durations'=>'Períodos de aluguer publicados','included'=>'Incluído','today'=>'Hoje'],
        'ca'=>['published'=>'Publicat','from'=>'des de','hours'=>'Horari','location'=>'RSB és a','near'=>'A prop de','deposit_none'=>'No es requereix fiança per a aquest lloguer.','deposit_scooter'=>'S’aplica una fiança reemborsable als scooters de motor; l’import no està especificat a les fonts locals.','id'=>'Pot requerir-se una identificació vàlida. Contacta amb RSB per confirmar el document necessari.','storage'=>'Hi ha consigna gratuïta d’equipatge per a tots els serveis de lloguer.','products'=>'RSB ofereix','contact'=>'Contacte RSB','children'=>'Hi ha bicicletes per a nens. Per a altres requisits específics, contacta amb RSB.','scooters'=>'RSB lloga scooters de gasolina de 50cc i 125cc. Els patinets elèctrics i e-bikes no consten com a serveis.','durations'=>'Períodes de lloguer publicats','included'=>'Inclòs','today'=>'Avui'],
        'sv'=>['published'=>'Publicerat','from'=>'från','hours'=>'Öppettider','location'=>'RSB finns på','near'=>'Nära','deposit_none'=>'Ingen deposition krävs för denna uthyrning.','deposit_scooter'=>'En återbetalningsbar deposition gäller för motorscootrar; beloppet anges inte i de lokala källorna.','id'=>'Giltig legitimation kan krävas. Kontakta RSB för att bekräfta vilket dokument som behövs.','storage'=>'Gratis bagageförvaring finns för alla uthyrningstjänster.','products'=>'RSB erbjuder','contact'=>'Kontakt RSB','children'=>'Barncyklar finns. Kontakta RSB för andra barns specifika krav.','scooters'=>'RSB hyr ut bensindrivna 50cc- och 125cc-motorscootrar. Elsparkcyklar och e-cyklar är inte listade.','durations'=>'Publicerade hyresperioder','included'=>'Ingår','today'=>'Idag'],
        'pl'=>['published'=>'Opublikowano','from'=>'od','hours'=>'Godziny otwarcia','location'=>'RSB znajduje się pod adresem','near'=>'W pobliżu','deposit_none'=>'Dla tego wynajmu kaucja nie jest wymagana.','deposit_scooter'=>'Dla skuterów silnikowych obowiązuje zwrotna kaucja; jej kwota nie jest podana w lokalnych źródłach.','id'=>'Może być wymagany ważny dokument tożsamości. Skontaktuj się z RSB, aby potwierdzić wymagany dokument.','storage'=>'Bezpłatne przechowywanie bagażu jest dostępne dla wszystkich usług wynajmu.','products'=>'RSB oferuje','contact'=>'Kontakt RSB','children'=>'Dostępne są rowery dla dzieci. W innych sprawach dotyczących dzieci skontaktuj się z RSB.','scooters'=>'RSB wynajmuje benzynowe skutery 50cc i 125cc. Hulajnogi elektryczne i e-rowery nie są wymienione.','durations'=>'Opublikowane okresy wynajmu','included'=>'W cenie','today'=>'Dzisiaj']
    ];
    return isset($all[$lang]) ? $all[$lang] : $all['en'];
}

function rsb_price_piece($product, $duration, $prices, $lang) {
    $labels = rsb_labels($lang);
    $service = rsb_find_service($prices, rsb_service_id_for_product($product));
    if (!$service) {
        return null;
    }
    if ($duration !== null) {
        foreach ($service['items'] as $item) {
            if (rsb_normalize($item['label'], []) === rsb_normalize($duration, [])) {
                return $service['name'] . ': ' . $item['price'] . ' € (' . $item['label'] . ').';
            }
        }
        return null;
    }
    return $service['name'] . ': ' . $labels['from'] . ' ' . $service['fromPrice'] . ' €.';
}

function rsb_duration_piece($product, $prices, $lang) {
    $service = rsb_find_service($prices, rsb_service_id_for_product($product));
    if (!$service) return null;
    $labels = rsb_labels($lang);
    $items = [];
    foreach ($service['items'] as $item) {
        $items[] = $item['label'] . ' ' . $item['price'] . ' €';
    }
    return $labels['durations'] . ': ' . implode('; ', $items) . '.';
}

function rsb_rate_limit($clientId, $config) {
    $dir = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'rsb_chat_v21_rate';
    if (!is_dir($dir)) {
        @mkdir($dir, 0700, true);
    }
    $minute = gmdate('YmdHi');
    $limits = [
        ['global_' . $minute, (int)$config['thresholds']['global_per_minute']],
        ['client_' . hash('sha256', $clientId) . '_' . $minute, (int)$config['thresholds']['per_client_per_minute']]
    ];
    foreach ($limits as $entry) {
        $path = $dir . DIRECTORY_SEPARATOR . $entry[0];
        $fp = @fopen($path, 'c+');
        if (!$fp) {
            continue;
        }
        flock($fp, LOCK_EX);
        $raw = stream_get_contents($fp);
        $count = (int)trim($raw);
        if ($count >= $entry[1]) {
            flock($fp, LOCK_UN);
            fclose($fp);
            return false;
        }
        $count++;
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, (string)$count);
        fflush($fp);
        flock($fp, LOCK_UN);
        fclose($fp);
    }
    if (mt_rand(1, 40) === 1 && is_dir($dir)) {
        foreach ((array)glob($dir . DIRECTORY_SEPARATOR . '*') as $old) {
            if (is_file($old) && @filemtime($old) < time() - 180) {
                @unlink($old);
            }
        }
    }
    return true;
}

function rsb_process($input, $config, $prices, $services, $faq) {
    $message = isset($input['message']) && is_string($input['message']) ? trim($input['message']) : '';
    $lang = rsb_language(isset($input['language']) ? $input['language'] : 'en', $config);
    $context = isset($input['context']) && is_array($input['context']) ? $input['context'] : [];
    $aliases = isset($config['aliases']) ? $config['aliases'] : [];
    $text = rsb_normalize($message, $aliases);
    $product = rsb_extract_product($text, $lang, $config);
    $duration = rsb_extract_duration($text);
    list($intents, $product, $follow) = rsb_detect_intents($text, $lang, $config, $product, $duration, $context);
    $labels = rsb_labels($lang);
    $tpl = isset($config['templates'][$lang]) ? $config['templates'][$lang] : $config['templates']['en'];

    $score = 0.50;
    if (count($intents) > 0 && !in_array('OUT_OF_SCOPE', $intents, true)) $score += 0.22;
    if ($product !== null) $score += 0.18;
    if ($duration !== null) $score += 0.10;
    if (in_array('MULTI_INTENT', $intents, true)) $score += 0.08;
    if (in_array('PRICE_DURATION', $intents, true) && $product === null) $score -= 0.25;
    $score = max(0.0, min(1.0, $score));

    $pieces = [];
    $fallbackNeeded = false;
    $sensitiveUnsupported = ['SIZE','GROUPS'];

    if (in_array('OUT_OF_SCOPE', $intents, true)) {
        $pieces[] = $tpl['out'];
    } else {
        if (in_array('COMPETITOR', $intents, true)) $pieces[] = $tpl['competitor'];
        if (in_array('AVAILABILITY', $intents, true)) $pieces[] = $tpl['availability'];
        if (in_array('BOOKING', $intents, true)) $pieces[] = $tpl['booking'];
        if (in_array('LICENSE', $intents, true)) $pieces[] = $tpl['license'];
        if (in_array('PAYMENT', $intents, true)) {
            $pieces[] = $product === 'inline_skates' ? $tpl['payment_inline'] : $tpl['payment'];
        }
        if (in_array('RETURN', $intents, true)) {
            if ($product === 'scooter') $pieces[] = $tpl['return_scooter'];
            else $fallbackNeeded = true;
        }
        foreach ($sensitiveUnsupported as $unsupported) {
            if (in_array($unsupported, $intents, true)) $fallbackNeeded = true;
        }

        if (in_array('GREETING', $intents, true)) {
            $greetings = ['en'=>'Hello. I am the RSB Assistant.','es'=>'Hola. Soy el Asistente RSB.','fr'=>'Bonjour. Je suis l’Assistant RSB.','it'=>'Ciao. Sono l’Assistente RSB.','de'=>'Hallo. Ich bin der RSB-Assistent.','nl'=>'Hallo. Ik ben de RSB-assistent.','pt'=>'Olá. Sou o Assistente RSB.','ca'=>'Hola. Soc l’Assistent RSB.','sv'=>'Hej. Jag är RSB-assistenten.','pl'=>'Cześć. Jestem Asystentem RSB.'];
            $pieces[] = $greetings[$lang];
        }
        if (in_array('HELP', $intents, true)) $pieces[] = $tpl['out'];

        if (in_array('PRODUCTS', $intents, true) && !in_array('PRICE', $intents, true)) {
            $names = [];
            foreach ($services['services'] as $service) $names[] = $service['name'];
            $pieces[] = $labels['products'] . ': ' . implode(', ', $names) . '.';
        }

        if (in_array('PRICE_DURATION', $intents, true) || in_array('PRICE', $intents, true)) {
            if ($product !== null) {
                $piece = rsb_price_piece($product, in_array('PRICE_DURATION', $intents, true) ? $duration : null, $prices, $lang);
                if ($piece !== null) $pieces[] = $piece; else $fallbackNeeded = true;
            } else {
                $fallbackNeeded = true;
            }
        }

        if (in_array('HOURS', $intents, true) || in_array('OPEN_TODAY', $intents, true)) {
            $h = [];
            foreach ($services['business']['openingHours'] as $row) $h[] = $row['days'] . ' ' . $row['hours'];
            $pieces[] = $labels['hours'] . ': ' . implode('; ', $h) . '.';
        }

        if (in_array('LOCATION', $intents, true) || in_array('MAPS', $intents, true)) {
            $a = $services['business']['address'];
            $pieces[] = $labels['location'] . ' ' . $a['street'] . ', ' . $a['postalCode'] . ' ' . $a['city'] . ', ' . $a['country'] . '. ' . $labels['near'] . ': ' . implode(', ', $services['business']['nearbyPlaces']) . '.';
        }

        if (in_array('DEPOSIT', $intents, true)) {
            if ($product === 'scooter') $pieces[] = $labels['deposit_scooter'];
            elseif ($product !== null) $pieces[] = $labels['deposit_none'];
            else $pieces[] = $labels['deposit_scooter'] . ' ' . $labels['deposit_none'];
        }

        if (in_array('ID_DOCUMENT', $intents, true)) {
            if ($product !== null && $product !== 'scooter') $pieces[] = $tpl['documents_non_scooter'];
            elseif ($product === 'scooter') $pieces[] = $tpl['license'];
            else $pieces[] = $tpl['documents'];
        }

        if (in_array('PROTECTIONS', $intents, true)) {
            if ($product !== null) {
                $id = rsb_service_id_for_product($product);
                $priceService = rsb_find_service($prices, $id);
                $service = rsb_find_service($services, $id);
                $inc = [];
                if ($priceService && isset($priceService['included'])) $inc = $priceService['included'];
                if ($product === 'scooter' && $service) $inc = ['Two helmets','Third-party insurance'];
                if ($inc) $pieces[] = $labels['included'] . ': ' . implode(', ', $inc) . '.'; else $fallbackNeeded = true;
            } else {
                $fallbackNeeded = true;
            }
        }

        if (in_array('STORAGE', $intents, true)) $pieces[] = $labels['storage'];

        if (in_array('CHILDREN', $intents, true)) $pieces[] = $labels['children'];

        if (in_array('DURATION', $intents, true) && !in_array('PRICE_DURATION', $intents, true)) {
            if ($product !== null) {
                $piece = rsb_duration_piece($product, $prices, $lang);
                if ($piece) $pieces[] = $piece; else $fallbackNeeded = true;
            } else $fallbackNeeded = true;
        }

        if (in_array('CONTACT', $intents, true)) {
            $b = $prices['business']['contact'];
            $pieces[] = $labels['contact'] . ': ' . $b['phone'] . '; ' . $b['email'] . '; WhatsApp ' . $b['whatsapp'] . '.';
        }

        if (in_array('NEAR_BEACH', $intents, true)) {
            $pieces[] = $labels['near'] . ': ' . implode(', ', $services['business']['nearbyPlaces']) . '.';
        }

        if (in_array('SCOOTER_50', $intents, true) || in_array('SCOOTER_125', $intents, true)) $pieces[] = $labels['scooters'];

        if ($fallbackNeeded) $pieces[] = $tpl['fallback'];
    }

    $pieces = array_values(array_unique(array_filter($pieces)));
    if (!$pieces) $pieces[] = $tpl['fallback'];

    $reply = implode(' ', $pieces);
    $newContext = [
        'product' => $product,
        'duration' => $duration,
        'scooter_class' => in_array('SCOOTER_125', $intents, true) ? '125cc' : (in_array('SCOOTER_50', $intents, true) ? '50cc' : null),
        'topic' => isset($intents[0]) ? $intents[0] : null,
        'last_intents' => array_slice($intents, 0, 4)
    ];

    return [
        'ok'=>true,
        'reply'=>$reply,
        'language'=>$lang,
        'intents'=>$intents,
        'entities'=>['product'=>$product,'duration'=>$duration,'scooter_class'=>$newContext['scooter_class']],
        'confidence'=>round($score, 2),
        'context'=>$newContext
    ];
}

$root = dirname(__DIR__);
$config = rsb_load_json($root . '/chatbot-config.json');
$prices = rsb_load_json($root . '/prices.json');
$services = rsb_load_json($root . '/services.json');
$faq = rsb_load_json($root . '/faq.json');
if (!$config || !$prices || !$services || !$faq) {
    rsb_json_response(500, ['ok'=>false,'error'=>'configuration_unavailable']);
}

$cliTest = PHP_SAPI === 'cli' && getenv('RSB_CHAT_CLI_TEST') === '1';
if ($cliTest) {
    $raw = stream_get_contents(STDIN);
    $input = json_decode($raw, true);
    if (!is_array($input)) rsb_json_response(400, ['ok'=>false,'error'=>'invalid_json']);
    rsb_json_response(200, rsb_process($input, $config, $prices, $services, $faq));
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    rsb_json_response(405, ['ok'=>false,'error'=>'method_not_allowed']);
}
$contentType = isset($_SERVER['CONTENT_TYPE']) ? strtolower($_SERVER['CONTENT_TYPE']) : '';
if (strpos($contentType, 'application/json') !== 0) {
    rsb_json_response(415, ['ok'=>false,'error'=>'json_required']);
}
if (isset($_SERVER['HTTP_ORIGIN']) && $_SERVER['HTTP_ORIGIN'] !== '') {
    $origin = parse_url($_SERVER['HTTP_ORIGIN']);
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
    $originHost = isset($origin['host']) ? $origin['host'] : '';
    if (isset($origin['port'])) $originHost .= ':' . $origin['port'];
    $originScheme = isset($origin['scheme']) ? strtolower($origin['scheme']) : '';
    $expectedScheme = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') ? 'https' : 'http';
    if ($originHost === '' || strcasecmp($originHost, $host) !== 0 || $originScheme !== $expectedScheme) {
        rsb_json_response(403, ['ok'=>false,'error'=>'origin_rejected']);
    }
}
$maxBody = (int)$config['thresholds']['max_body_bytes'];
$contentLength = isset($_SERVER['CONTENT_LENGTH']) ? (int)$_SERVER['CONTENT_LENGTH'] : 0;
if ($contentLength > $maxBody) {
    rsb_json_response(413, ['ok'=>false,'error'=>'payload_too_large']);
}
$raw = file_get_contents('php://input');
if ($raw === false || strlen($raw) > $maxBody) {
    rsb_json_response(413, ['ok'=>false,'error'=>'payload_too_large']);
}
$input = json_decode($raw, true);
if (!is_array($input)) {
    rsb_json_response(400, ['ok'=>false,'error'=>'invalid_json']);
}
if (isset($input['website']) && $input['website'] !== '') {
    rsb_json_response(400, ['ok'=>false,'error'=>'request_rejected']);
}
$message = isset($input['message']) && is_string($input['message']) ? trim($input['message']) : '';
if ($message === '') {
    rsb_json_response(400, ['ok'=>false,'error'=>'message_required']);
}
if (rsb_strlen($message) > (int)$config['thresholds']['max_message_length']) {
    rsb_json_response(413, ['ok'=>false,'error'=>'message_too_long']);
}
$clientId = isset($input['client_id']) && is_string($input['client_id']) ? $input['client_id'] : '';
if (!preg_match('/^[A-Za-z0-9_-]{16,80}$/', $clientId)) {
    rsb_json_response(400, ['ok'=>false,'error'=>'client_id_required']);
}
if (!rsb_rate_limit($clientId, $config)) {
    rsb_json_response(429, ['ok'=>false,'error'=>'rate_limited']);
}
rsb_json_response(200, rsb_process($input, $config, $prices, $services, $faq));
