<?php

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

/*
 |---------------------------------------------------------------
 | OFFICIAL OPENING HOURS — effective 2026-09-20
 | Sunday–Thursday: 10:30–14:00 and 16:30–19:00
 | Friday–Saturday: 10:30–14:00 and 16:30–20:00
 |---------------------------------------------------------------
 */
$timezone = new DateTimeZone('Europe/Madrid');
$now = new DateTimeImmutable('now', $timezone);
$today = $now->format('Y-m-d');
$dayNumber = (int) $now->format('N'); // 1=Monday ... 7=Sunday

$morningOpens = '10:30';
$morningCloses = '14:00';
$afternoonOpens = '16:30';
$afternoonCloses = in_array($dayNumber, [5, 6], true) ? '20:00' : '19:00';

$morningOpenAt = new DateTimeImmutable($today . ' ' . $morningOpens, $timezone);
$morningCloseAt = new DateTimeImmutable($today . ' ' . $morningCloses, $timezone);
$afternoonOpenAt = new DateTimeImmutable($today . ' ' . $afternoonOpens, $timezone);
$afternoonCloseAt = new DateTimeImmutable($today . ' ' . $afternoonCloses, $timezone);

$isOpen = ($now >= $morningOpenAt && $now < $morningCloseAt)
    || ($now >= $afternoonOpenAt && $now < $afternoonCloseAt);

$sundayThursdayDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'];
$fridaySaturdayDays = ['Friday', 'Saturday'];
$sundayThursday = '10:30–14:00 and 16:30–19:00';
$fridaySaturday = '10:30–14:00 and 16:30–20:00';
$todayHours = $morningOpens . '–' . $morningCloses . ' and ' . $afternoonOpens . '–' . $afternoonCloses;

$openingHoursSpecification = [
    [
        '@type' => 'OpeningHoursSpecification',
        'dayOfWeek' => $sundayThursdayDays,
        'opens' => '10:30',
        'closes' => '14:00',
    ],
    [
        '@type' => 'OpeningHoursSpecification',
        'dayOfWeek' => $sundayThursdayDays,
        'opens' => '16:30',
        'closes' => '19:00',
    ],
    [
        '@type' => 'OpeningHoursSpecification',
        'dayOfWeek' => $fridaySaturdayDays,
        'opens' => '10:30',
        'closes' => '14:00',
    ],
    [
        '@type' => 'OpeningHoursSpecification',
        'dayOfWeek' => $fridaySaturdayDays,
        'opens' => '16:30',
        'closes' => '20:00',
    ],
];

$payload = [
    'ok' => true,
    'is_open' => $isOpen,
    'timezone' => $timezone->getName(),
    'current_time' => $now->format(DATE_ATOM),
    'effective_from' => '2026-09-20',
    'sunday_thursday' => $sundayThursday,
    'friday_saturday' => $fridaySaturday,
    'today' => $todayHours,
    // Backward-compatible fields now describe today's two periods.
    'morning' => $morningOpens . '–' . $morningCloses,
    'afternoon' => $afternoonOpens . '–' . $afternoonCloses,
    'morning_opens' => $morningOpens,
    'morning_closes' => $morningCloses,
    'afternoon_opens' => $afternoonOpens,
    'afternoon_closes' => $afternoonCloses,
    'openingHoursSpecification' => $openingHoursSpecification,
];

echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
