(() => {
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  const header = $('.site-header');
  let scrollTicking = false;
  const updateHeaderOnScroll = () => {
    if (!header) return;
    header.classList.toggle('scrolled', window.scrollY > 50);
  };
  const onScroll = () => {
    if (scrollTicking) return;
    scrollTicking = true;
    window.requestAnimationFrame(() => {
      updateHeaderOnScroll();
      scrollTicking = false;
    });
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  updateHeaderOnScroll();

  const menuBtn = $('#mobileMenuBtn');
  const mobileMenu = $('#mobileMenu');
  const setMenu = (open) => {
    if (!mobileMenu) return;
    mobileMenu.classList.toggle('open', open);
    if (menuBtn) menuBtn.setAttribute('aria-expanded', String(open));
    const iconOpen = $('#iconMenu');
    const iconClose = $('#iconClose');
    if (iconOpen && iconClose) {
      iconOpen.style.display = open ? 'none' : 'block';
      iconClose.style.display = open ? 'block' : 'none';
    }
  };
  if (menuBtn) {
    menuBtn.addEventListener('click', () => {
      const isOpen = mobileMenu?.classList.contains('open');
      setMenu(!isOpen);
    });
  }
  $$('.m-link').forEach((a) => a.addEventListener('click', () => setMenu(false)));

  const dropdown = $('#langDropdown');
  const trigger = $('#langTrigger');
  const toggleDropdown = (open) => {
    if (!dropdown) return;
    dropdown.classList.toggle('open', open);
    if (trigger) trigger.setAttribute('aria-expanded', String(open));
  };
  if (trigger && dropdown) {
    trigger.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggleDropdown(!dropdown.classList.contains('open'));
    });
    document.addEventListener('click', (e) => {
      if (!dropdown.contains(e.target)) toggleDropdown(false);
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') toggleDropdown(false);
    });
  }

  const mobileDropdown = $('#langDropdownMobile');
  const mobileTrigger = $('#langTriggerMobile');
  const toggleMobileDropdown = (open) => {
    if (!mobileDropdown) return;
    mobileDropdown.classList.toggle('open', open);
    if (mobileTrigger) mobileTrigger.setAttribute('aria-expanded', String(open));
  };
  if (mobileTrigger && mobileDropdown) {
    mobileTrigger.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggleMobileDropdown(!mobileDropdown.classList.contains('open'));
    });
    document.addEventListener('click', (e) => {
      if (!mobileDropdown.contains(e.target)) toggleMobileDropdown(false);
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') toggleMobileDropdown(false);
    });
  }

  $$('.faq-item').forEach((item) => {
    const btn = $('.faq-q', item);
    if (!btn) return;
    btn.addEventListener('click', () => {
      const isOpen = item.classList.contains('open');
      $$('.faq-item.open').forEach((i) => {
        i.classList.remove('open');
        const openButton = $('.faq-q', i);
        if (openButton) openButton.setAttribute('aria-expanded', 'false');
      });
      if (!isOpen) {
        item.classList.add('open');
        btn.setAttribute('aria-expanded', 'true');
      } else {
        btn.setAttribute('aria-expanded', 'false');
      }
    });
  });

  const revealEls = $$('.reveal');
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) {
          en.target.classList.add('in-view');
          io.unobserve(en.target);
        }
      });
    }, { rootMargin: '0px 0px -50px 0px', threshold: 0.1 });
    revealEls.forEach((el) => io.observe(el));
  } else {
    revealEls.forEach((el) => el.classList.add('in-view'));
  }

  const translations = {
    en: {
      sunThuLabel: 'Sunday–Thursday',
      join: 'and',
      friSatLabel: 'Friday–Saturday',
      practicalSentence: (sunThu, friSat) => `RSB Rental Scooter Barcelona opening hours: Sunday–Thursday ${sunThu}; Friday–Saturday ${friSat}.`,
    },
    es: {
      sunThuLabel: 'Domingo–jueves',
      join: 'y',
      friSatLabel: 'Viernes–sábado',
      practicalSentence: (sunThu, friSat) => `Horario de RSB Rental Scooter Barcelona: domingo–jueves ${sunThu}; viernes–sábado ${friSat}.`,
    },
    fr: {
      sunThuLabel: 'Dimanche–jeudi',
      join: 'et',
      friSatLabel: 'Vendredi–samedi',
      practicalSentence: (sunThu, friSat) => `Horaires de RSB Rental Scooter Barcelona : dimanche–jeudi ${sunThu} ; vendredi–samedi ${friSat}.`,
    },
    it: {
      sunThuLabel: 'Domenica–giovedì',
      join: 'e',
      friSatLabel: 'Venerdì–sabato',
      practicalSentence: (sunThu, friSat) => `Orari di RSB Rental Scooter Barcelona: domenica–giovedì ${sunThu}; venerdì–sabato ${friSat}.`,
    },
    de: {
      sunThuLabel: 'Sonntag–Donnerstag',
      join: 'und',
      friSatLabel: 'Freitag–Samstag',
      practicalSentence: (sunThu, friSat) => `Öffnungszeiten von RSB Rental Scooter Barcelona: Sonntag–Donnerstag ${sunThu}; Freitag–Samstag ${friSat}.`,
    },
    nl: {
      sunThuLabel: 'Zondag–donderdag',
      join: 'en',
      friSatLabel: 'Vrijdag–zaterdag',
      practicalSentence: (sunThu, friSat) => `Openingstijden van RSB Rental Scooter Barcelona: zondag–donderdag ${sunThu}; vrijdag–zaterdag ${friSat}.`,
    },
    ca: {
      sunThuLabel: 'Diumenge–dijous',
      join: 'i',
      friSatLabel: 'Divendres–dissabte',
      practicalSentence: (sunThu, friSat) => `Horari de RSB Rental Scooter Barcelona: diumenge–dijous ${sunThu}; divendres–dissabte ${friSat}.`,
    },
    pt: {
      sunThuLabel: 'Domingo–quinta-feira',
      join: 'e',
      friSatLabel: 'Sexta-feira–sábado',
      practicalSentence: (sunThu, friSat) => `Horário da RSB Rental Scooter Barcelona: domingo–quinta-feira ${sunThu}; sexta-feira–sábado ${friSat}.`,
    },
    sv: {
      sunThuLabel: 'Söndag–torsdag',
      join: 'och',
      friSatLabel: 'Fredag–lördag',
      practicalSentence: (sunThu, friSat) => `Öppettider för RSB Rental Scooter Barcelona: söndag–torsdag ${sunThu}; fredag–lördag ${friSat}.`,
    },
    pl: {
      sunThuLabel: 'Niedziela–czwartek',
      join: 'i',
      friSatLabel: 'Piątek–sobota',
      practicalSentence: (sunThu, friSat) => `Godziny otwarcia RSB Rental Scooter Barcelona: niedziela–czwartek ${sunThu}; piątek–sobota ${friSat}.`,
    },
  };

  const normalizeLang = () => {
    const raw = (document.documentElement.lang || 'en').toLowerCase();
    const base = raw.split('-')[0];
    if (base === 'cat') return 'ca';
    return translations[base] ? base : 'en';
  };


  const ANALYTICS_ID = 'G-S7SMLHCNGK';

  const initAnalytics = () => {
    window.dataLayer = window.dataLayer || [];
    window.gtag = window.gtag || function gtag(){ window.dataLayer.push(arguments); };
    window.gtag('js', new Date());
    window.gtag('config', ANALYTICS_ID);

    let loaded = false;

    const loadAnalytics = () => {
      if (loaded) return;
      loaded = true;

      const script = document.createElement('script');
      script.async = true;
      script.src = `https://www.googletagmanager.com/gtag/js?id=${ANALYTICS_ID}`;
      document.head.appendChild(script);
    };

    ['pointerdown', 'touchstart', 'keydown'].forEach((eventName) => {
      window.addEventListener(eventName, loadAnalytics, { once: true, passive: true });
    });

    window.addEventListener('load', loadAnalytics, { once: true });
  };

  const formatGroupHours = (value, joinWord) => {
    if (typeof value !== 'string') return value;
    return value.replace(/\s+and\s+/i, ` ${joinWord} `);
  };

  const setStrongHours = (el, prefix, hours) => {
    if (!el) return;
    el.innerHTML = `<strong>${prefix}</strong>: ${hours}`;
  };

  const setPlainHours = (el, prefix, hours) => {
    if (!el) return;
    el.textContent = `${prefix}: ${hours}`;
  };

  const updatePracticalText = (el, sentence) => {
    if (!el) return;
    const html = el.innerHTML;
    const breakPattern = /<br\s*\/?>\s*<br\s*\/?>/i;
    if (breakPattern.test(html)) {
      const parts = html.split(breakPattern);
      if (parts.length > 1) {
        el.innerHTML = `${sentence}<br><br>${parts.slice(1).join('<br><br>')}`;
        return;
      }
    }

    const blankLinePattern = /\n\s*\n/;
    if (blankLinePattern.test(html)) {
      const parts = html.split(blankLinePattern);
      if (parts.length > 1) {
        el.innerHTML = `${sentence}\n\n${parts.slice(1).join('\n\n')}`;
        return;
      }
    }

    el.textContent = sentence;
  };

  const replaceOpeningHoursSpec = (node, spec) => {
    if (!node || typeof node !== 'object') return;
    if (Array.isArray(node)) {
      node.forEach((item) => replaceOpeningHoursSpec(item, spec));
      return;
    }
    Object.keys(node).forEach((key) => {
      if (key === 'openingHoursSpecification' && Array.isArray(node[key])) {
        node[key] = spec;
      } else {
        replaceOpeningHoursSpec(node[key], spec);
      }
    });
  };

  const updateJsonLdHours = (spec) => {
    $$('script[type="application/ld+json"]').forEach((script) => {
      try {
        const data = JSON.parse(script.textContent);
        replaceOpeningHoursSpec(data, spec);
        script.textContent = JSON.stringify(data);
      } catch (error) {
        // Ignore invalid or non-JSON-LD blocks.
      }
    });
  };

  const defaultOpeningHoursSpecification = [
    {
      '@type': 'OpeningHoursSpecification',
      dayOfWeek: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'],
      opens: '10:30',
      closes: '14:00',
    },
    {
      '@type': 'OpeningHoursSpecification',
      dayOfWeek: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday'],
      opens: '16:30',
      closes: '19:00',
    },
    {
      '@type': 'OpeningHoursSpecification',
      dayOfWeek: ['Friday', 'Saturday'],
      opens: '10:30',
      closes: '14:00',
    },
    {
      '@type': 'OpeningHoursSpecification',
      dayOfWeek: ['Friday', 'Saturday'],
      opens: '16:30',
      closes: '20:00',
    },
  ];

  const normalizeHoursPayload = (data) => {
    if (!data || typeof data !== 'object') return null;

    const sundayThursday = typeof data.sunday_thursday === 'string'
      ? data.sunday_thursday
      : '10:30–14:00 and 16:30–19:00';
    const fridaySaturday = typeof data.friday_saturday === 'string'
      ? data.friday_saturday
      : '10:30–14:00 and 16:30–20:00';

    return {
      ...data,
      sunday_thursday: sundayThursday,
      friday_saturday: fridaySaturday,
      openingHoursSpecification: Array.isArray(data.openingHoursSpecification)
        ? data.openingHoursSpecification
        : defaultOpeningHoursSpecification,
    };
  };

  const fetchHours = async () => {
    try {
      const res = await fetch('/api/hours.php', { cache: 'no-store' });
      if (!res.ok) return null;
      return normalizeHoursPayload(await res.json());
    } catch (error) {
      // Keep the corrected static hours already present in the HTML.
    }

    return null;
  };

  const renderHours = async () => {
    const lang = normalizeLang();
    const copy = translations[lang];
    const data = await fetchHours();
    if (!data) return;

    const sundayThursday = formatGroupHours(data.sunday_thursday, copy.join);
    const fridaySaturday = formatGroupHours(data.friday_saturday, copy.join);
    const sentence = copy.practicalSentence(sundayThursday, fridaySaturday);

    setPlainHours($('#rsbHoursContactPrimary'), copy.sunThuLabel, sundayThursday);
    setStrongHours($('#rsbHoursContactSecondary'), copy.friSatLabel, fridaySaturday);
    ['#rsbHoursFooterPrimary', '#rsbHorarioFooterPrimary', '#rsbOrariFooterPrimary'].forEach((selector) =>
      setPlainHours($(selector), copy.sunThuLabel, sundayThursday));
    ['#rsbHoursFooterSecondary', '#rsbHorarioFooterSecondary', '#rsbOrariFooterSecondary'].forEach((selector) =>
      setStrongHours($(selector), copy.friSatLabel, fridaySaturday));
    updatePracticalText($('#rsbHoursPracticalText'), sentence);

    $$('[data-rsb-hours="weekday-line-html"]').forEach((el) => setStrongHours(el, copy.sunThuLabel, sundayThursday));
    $$('[data-rsb-hours="weekend-line-html"]').forEach((el) => setStrongHours(el, copy.friSatLabel, fridaySaturday));
    $$('[data-rsb-hours="weekday-line"]').forEach((el) => setPlainHours(el, copy.sunThuLabel, sundayThursday));
    $$('[data-rsb-hours="weekend-line"]').forEach((el) => setPlainHours(el, copy.friSatLabel, fridaySaturday));
    $$('[data-rsb-hours="sentence"]').forEach((el) => updatePracticalText(el, sentence));

    if (Array.isArray(data.openingHoursSpecification)) {
      updateJsonLdHours(data.openingHoursSpecification);
    }
  };

  initAnalytics();

  const scheduleHours = () => {
    const run = () => renderHours();
    if ('requestIdleCallback' in window) {
      window.requestIdleCallback(run, { timeout: 2500 });
    } else {
      window.setTimeout(run, 1200);
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', scheduleHours);
  } else {
    scheduleHours();
  }

  const year = $('#year');
  if (year) year.textContent = String(new Date().getFullYear());
})();
