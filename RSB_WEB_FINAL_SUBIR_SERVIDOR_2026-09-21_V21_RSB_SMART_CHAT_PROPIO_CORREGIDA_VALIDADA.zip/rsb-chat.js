(function () {
  'use strict';

  var VERSION = '20260929';
  var ENDPOINT = '/api/rsb-chat.php';
  var CONFIG_URL = '/chatbot-config.json?v=' + VERSION;
  var supported = ['en', 'es', 'fr', 'it', 'de', 'nl', 'pt', 'ca', 'sv', 'pl'];
  var rawLang = (document.documentElement.getAttribute('lang') || 'en').toLowerCase();
  var lang = rawLang.split('-')[0];
  if (supported.indexOf(lang) === -1) lang = 'en';

  var fallbackUI = {
    title: lang === 'es' ? 'Asistente RSB' : 'RSB Assistant',
    placeholder: lang === 'es' ? 'Pregunta sobre alquileres…' : 'Ask about rentals…',
    send: lang === 'es' ? 'Enviar' : 'Send',
    close: lang === 'es' ? 'Cerrar chat' : 'Close chat',
    open: lang === 'es' ? 'Abrir Asistente RSB' : 'Open RSB Assistant',
    privacy: lang === 'es'
      ? 'No introduzcas contraseñas, datos de tarjeta, números de DNI/pasaporte ni información sensible.'
      : 'Do not enter passwords, card details, ID/passport numbers or sensitive information.',
    quick: lang === 'es' ? ['Precios', 'Horarios', 'Documentación', 'Ubicación'] : ['Prices', 'Opening hours', 'Documents', 'Location'],
    thinking: lang === 'es' ? 'Consultando…' : 'Checking…',
    error: lang === 'es' ? 'No he podido completar la consulta. Contacta con RSB.' : 'I could not complete the request. Please contact RSB.'
  };

  var ui = fallbackUI;
  var context = {};
  var busy = false;
  var opened = false;
  var clientId = createClientId();

  function createClientId() {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return window.crypto.randomUUID().replace(/-/g, '');
    }
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
      var bytes = new Uint8Array(16);
      window.crypto.getRandomValues(bytes);
      return Array.prototype.map.call(bytes, function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
    }
    return String(Date.now()) + 'rsbchatclient';
  }

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (typeof text === 'string') node.textContent = text;
    return node;
  }

  var style = document.createElement('style');
  style.textContent = [
    '.rsb-chat-launch{position:fixed;right:max(16px,env(safe-area-inset-right));bottom:max(16px,env(safe-area-inset-bottom));z-index:2147482000;border:0;border-radius:999px;background:#0b5f45;color:#fff;padding:13px 18px;font:600 15px/1.2 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.24);cursor:pointer}',
    '.rsb-chat-panel{position:fixed;right:max(12px,env(safe-area-inset-right));bottom:calc(76px + env(safe-area-inset-bottom));z-index:2147482001;width:min(390px,calc(100vw - 24px));height:min(620px,calc(100dvh - 110px));background:#fff;color:#17202a;border:1px solid rgba(0,0,0,.12);border-radius:18px;box-shadow:0 12px 40px rgba(0,0,0,.28);display:none;overflow:hidden;font:14px/1.45 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}',
    '.rsb-chat-panel[data-open="true"]{display:flex;flex-direction:column}',
    '.rsb-chat-head{display:flex;align-items:center;justify-content:space-between;padding:13px 14px;background:#0b5f45;color:#fff}',
    '.rsb-chat-title{font-weight:700;font-size:16px}',
    '.rsb-chat-close{border:0;background:transparent;color:#fff;font-size:24px;line-height:1;cursor:pointer;padding:4px 7px}',
    '.rsb-chat-messages{flex:1;overflow:auto;padding:13px;background:#f6f8f7;overscroll-behavior:contain}',
    '.rsb-chat-msg{max-width:86%;margin:0 0 10px;padding:9px 11px;border-radius:13px;white-space:pre-wrap;overflow-wrap:anywhere}',
    '.rsb-chat-user{margin-left:auto;background:#dff2ea}',
    '.rsb-chat-bot{margin-right:auto;background:#fff;border:1px solid #e1e5e3}',
    '.rsb-chat-quick{display:grid;grid-template-columns:1fr 1fr;gap:7px;padding:9px 12px 5px;background:#fff}',
    '.rsb-chat-quick button{border:1px solid #b9cec5;border-radius:999px;background:#fff;color:#17493a;padding:8px 9px;cursor:pointer;font:600 13px/1.2 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}',
    '.rsb-chat-privacy{padding:6px 12px 8px;background:#fff;color:#5d6662;font-size:11px;line-height:1.35}',
    '.rsb-chat-form{display:flex;gap:7px;padding:9px 12px calc(9px + env(safe-area-inset-bottom));background:#fff;border-top:1px solid #e4e7e5}',
    '.rsb-chat-input{min-width:0;flex:1;border:1px solid #b8c3be;border-radius:10px;padding:10px 11px;font:14px/1.3 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}',
    '.rsb-chat-send{border:0;border-radius:10px;background:#0b5f45;color:#fff;padding:10px 13px;font-weight:700;cursor:pointer}',
    '.rsb-chat-send:disabled,.rsb-chat-input:disabled{opacity:.55;cursor:default}',
    '.rsb-chat-hp{position:absolute!important;left:-10000px!important;width:1px!important;height:1px!important;overflow:hidden!important}',
    '@media (max-width:600px){.rsb-chat-panel{right:0;bottom:0;width:100vw;height:100dvh;max-height:100dvh;border-radius:0;border:0}.rsb-chat-launch{right:max(12px,env(safe-area-inset-right));bottom:max(12px,env(safe-area-inset-bottom))}}',
    '@media (prefers-reduced-motion:reduce){.rsb-chat-launch,.rsb-chat-panel{scroll-behavior:auto}}'
  ].join('');
  document.head.appendChild(style);

  var launch = el('button', 'rsb-chat-launch', ui.title);
  launch.type = 'button';
  launch.setAttribute('aria-label', ui.open);
  launch.setAttribute('aria-expanded', 'false');

  var panel = el('section', 'rsb-chat-panel');
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-modal', 'false');
  panel.setAttribute('aria-label', ui.title);
  panel.setAttribute('data-open', 'false');

  var head = el('div', 'rsb-chat-head');
  var title = el('div', 'rsb-chat-title', ui.title);
  var close = el('button', 'rsb-chat-close', '×');
  close.type = 'button';
  close.setAttribute('aria-label', ui.close);
  head.appendChild(title);
  head.appendChild(close);

  var messages = el('div', 'rsb-chat-messages');
  messages.setAttribute('role', 'log');
  messages.setAttribute('aria-live', 'polite');
  messages.setAttribute('aria-relevant', 'additions text');

  var quick = el('div', 'rsb-chat-quick');
  var quickButtons = [];
  for (var i = 0; i < 4; i++) {
    var qb = el('button', '', ui.quick[i]);
    qb.type = 'button';
    quick.appendChild(qb);
    quickButtons.push(qb);
  }

  var privacy = el('div', 'rsb-chat-privacy', ui.privacy);
  var form = el('form', 'rsb-chat-form');
  var input = el('input', 'rsb-chat-input');
  input.type = 'text';
  input.maxLength = 500;
  input.autocomplete = 'off';
  input.spellcheck = true;
  input.placeholder = ui.placeholder;
  input.setAttribute('aria-label', ui.placeholder);
  var honeypot = el('input', 'rsb-chat-hp');
  honeypot.type = 'text';
  honeypot.name = 'website';
  honeypot.tabIndex = -1;
  honeypot.autocomplete = 'off';
  honeypot.setAttribute('aria-hidden', 'true');
  var send = el('button', 'rsb-chat-send', ui.send);
  send.type = 'submit';
  form.appendChild(input);
  form.appendChild(honeypot);
  form.appendChild(send);

  panel.appendChild(head);
  panel.appendChild(messages);
  panel.appendChild(quick);
  panel.appendChild(privacy);
  panel.appendChild(form);
  document.body.appendChild(launch);
  document.body.appendChild(panel);

  function applyUI(next) {
    if (!next) return;
    ui = next;
    title.textContent = ui.title;
    launch.textContent = ui.title;
    launch.setAttribute('aria-label', ui.open);
    close.setAttribute('aria-label', ui.close);
    panel.setAttribute('aria-label', ui.title);
    input.placeholder = ui.placeholder;
    input.setAttribute('aria-label', ui.placeholder);
    send.textContent = ui.send;
    privacy.textContent = ui.privacy;
    for (var j = 0; j < quickButtons.length; j++) quickButtons[j].textContent = ui.quick[j] || fallbackUI.quick[j];
  }

  fetch(CONFIG_URL, { credentials: 'same-origin', cache: 'no-store' })
    .then(function (r) { return r.ok ? r.json() : null; })
    .then(function (cfg) {
      if (cfg && cfg.ui && cfg.ui[lang]) applyUI(cfg.ui[lang]);
    })
    .catch(function () {});

  function setOpen(value) {
    opened = !!value;
    panel.setAttribute('data-open', opened ? 'true' : 'false');
    launch.setAttribute('aria-expanded', opened ? 'true' : 'false');
    launch.style.display = opened ? 'none' : '';
    if (opened) window.setTimeout(function () { input.focus(); }, 0);
  }

  function addMessage(text, who) {
    var node = el('div', 'rsb-chat-msg ' + (who === 'user' ? 'rsb-chat-user' : 'rsb-chat-bot'), text);
    messages.appendChild(node);
    messages.scrollTop = messages.scrollHeight;
    return node;
  }

  function setBusy(value) {
    busy = !!value;
    input.disabled = busy;
    send.disabled = busy;
    for (var k = 0; k < quickButtons.length; k++) quickButtons[k].disabled = busy;
  }

  function ask(question) {
    var text = String(question || '').trim();
    if (!text || busy) return;
    if (text.length > 500) text = text.slice(0, 500);
    addMessage(text, 'user');
    input.value = '';
    setBusy(true);
    var waiting = addMessage(ui.thinking, 'bot');
    var controller = new AbortController();
    var timer = window.setTimeout(function () { controller.abort(); }, 8000);
    var payload = {
      message: text,
      language: lang,
      context: context,
      client_id: clientId,
      website: honeypot.value || ''
    };
    fetch(ENDPOINT, {
      method: 'POST',
      credentials: 'same-origin',
      cache: 'no-store',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: controller.signal
    })
      .then(function (response) {
        if (!response.ok) throw new Error('http_' + response.status);
        return response.json();
      })
      .then(function (data) {
        if (!data || data.ok !== true || typeof data.reply !== 'string') throw new Error('invalid_response');
        waiting.textContent = data.reply;
        if (data.context && typeof data.context === 'object') context = data.context;
      })
      .catch(function () { waiting.textContent = ui.error; })
      .finally(function () {
        window.clearTimeout(timer);
        setBusy(false);
        if (opened) input.focus();
      });
  }

  launch.addEventListener('click', function () { setOpen(true); });
  close.addEventListener('click', function () { setOpen(false); });
  form.addEventListener('submit', function (event) {
    event.preventDefault();
    ask(input.value);
  });
  quickButtons.forEach(function (button) {
    button.addEventListener('click', function () { ask(button.textContent); });
  });
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape' && opened) setOpen(false);
  });
})();
