(() => {
  'use strict';

  if (window.__RSB_AI_CHAT_LOADED__) return;
  window.__RSB_AI_CHAT_LOADED__ = true;

  const I18N = {
    en: {
      open: 'Ask RSB',
      title: 'RSB AI Assistant',
      intro: 'Ask me about RSB rentals, prices, opening hours, documents, equipment or location.',
      placeholder: 'Ask a question...',
      send: 'Send',
      close: 'Close',
      contact: 'Contact RSB',
      notice: 'AI assistant. Messages are processed by OpenAI to generate a reply. Do not include passwords, payment-card data, ID/passport numbers or other sensitive information.',
      error: 'I cannot answer right now. Please contact RSB directly.',
      thinking: 'Checking RSB information...',
      chips: ['Rental prices', 'Opening hours', 'Documents needed', 'Where is RSB?']
    },
    es: {
      open: 'Pregunta a RSB',
      title: 'Asistente IA de RSB',
      intro: 'Pregúntame sobre alquileres, precios, horarios, documentación, equipamiento o ubicación de RSB.',
      placeholder: 'Escribe tu pregunta...',
      send: 'Enviar',
      close: 'Cerrar',
      contact: 'Contactar con RSB',
      notice: 'Asistente con IA. Tus mensajes se procesan mediante OpenAI para generar la respuesta. No incluyas contraseñas, datos de tarjetas, DNI/pasaporte ni otra información sensible.',
      error: 'Ahora mismo no puedo responder. Contacta directamente con RSB.',
      thinking: 'Consultando la información de RSB...',
      chips: ['Precios de alquiler', 'Horarios', 'Documentación', '¿Dónde está RSB?']
    },
    fr: {
      open: 'Demander à RSB',
      title: 'Assistant IA RSB',
      intro: 'Posez vos questions sur les locations, tarifs, horaires, documents, équipements ou l’emplacement de RSB.',
      placeholder: 'Posez votre question...',
      send: 'Envoyer',
      close: 'Fermer',
      contact: 'Contacter RSB',
      notice: 'Assistant IA. Vos messages sont traités par OpenAI afin de générer une réponse. Ne communiquez pas de mots de passe, données bancaires, numéros de pièce d’identité/passeport ni d’autres données sensibles.',
      error: 'Je ne peux pas répondre pour le moment. Contactez directement RSB.',
      thinking: 'Consultation des informations RSB...',
      chips: ['Tarifs', 'Horaires', 'Documents requis', 'Où se trouve RSB ?']
    },
    it: {
      open: 'Chiedi a RSB',
      title: 'Assistente IA RSB',
      intro: 'Chiedimi informazioni su noleggi, prezzi, orari, documenti, attrezzatura o posizione di RSB.',
      placeholder: 'Scrivi una domanda...',
      send: 'Invia',
      close: 'Chiudi',
      contact: 'Contatta RSB',
      notice: 'Assistente IA. I messaggi vengono elaborati da OpenAI per generare una risposta. Non inserire password, dati di carte, numeri di documenti/passaporto o altre informazioni sensibili.',
      error: 'Al momento non posso rispondere. Contatta direttamente RSB.',
      thinking: 'Consultazione delle informazioni RSB...',
      chips: ['Prezzi', 'Orari', 'Documenti necessari', 'Dove si trova RSB?']
    },
    de: {
      open: 'RSB fragen',
      title: 'RSB KI-Assistent',
      intro: 'Fragen Sie nach RSB-Mietangeboten, Preisen, Öffnungszeiten, Dokumenten, Ausrüstung oder Standort.',
      placeholder: 'Frage eingeben...',
      send: 'Senden',
      close: 'Schließen',
      contact: 'RSB kontaktieren',
      notice: 'KI-Assistent. Nachrichten werden von OpenAI verarbeitet, um eine Antwort zu erzeugen. Bitte keine Passwörter, Kartendaten, Ausweis-/Passnummern oder andere sensible Daten eingeben.',
      error: 'Ich kann derzeit nicht antworten. Bitte kontaktieren Sie RSB direkt.',
      thinking: 'RSB-Informationen werden geprüft...',
      chips: ['Mietpreise', 'Öffnungszeiten', 'Benötigte Dokumente', 'Wo ist RSB?']
    },
    nl: {
      open: 'Vraag RSB',
      title: 'RSB AI-assistent',
      intro: 'Vraag naar RSB-verhuur, prijzen, openingstijden, documenten, uitrusting of locatie.',
      placeholder: 'Stel een vraag...',
      send: 'Versturen',
      close: 'Sluiten',
      contact: 'Contact RSB',
      notice: 'AI-assistent. Berichten worden door OpenAI verwerkt om een antwoord te genereren. Deel geen wachtwoorden, betaalkaartgegevens, ID-/paspoortnummers of andere gevoelige informatie.',
      error: 'Ik kan momenteel niet antwoorden. Neem rechtstreeks contact op met RSB.',
      thinking: 'RSB-informatie controleren...',
      chips: ['Huurprijzen', 'Openingstijden', 'Benodigde documenten', 'Waar is RSB?']
    },
    pt: {
      open: 'Perguntar à RSB',
      title: 'Assistente IA RSB',
      intro: 'Pergunte sobre alugueres, preços, horários, documentos, equipamento ou localização da RSB.',
      placeholder: 'Faça uma pergunta...',
      send: 'Enviar',
      close: 'Fechar',
      contact: 'Contactar RSB',
      notice: 'Assistente de IA. As mensagens são processadas pela OpenAI para gerar uma resposta. Não inclua palavras-passe, dados de cartões, números de identificação/passaporte ou outros dados sensíveis.',
      error: 'Não consigo responder neste momento. Contacte diretamente a RSB.',
      thinking: 'A consultar informações da RSB...',
      chips: ['Preços', 'Horários', 'Documentos necessários', 'Onde fica a RSB?']
    },
    ca: {
      open: 'Pregunta a RSB',
      title: 'Assistent IA de RSB',
      intro: 'Pregunta’m sobre lloguers, preus, horaris, documentació, equipament o ubicació de RSB.',
      placeholder: 'Escriu la teva pregunta...',
      send: 'Enviar',
      close: 'Tancar',
      contact: 'Contactar amb RSB',
      notice: 'Assistent amb IA. Els missatges es processen mitjançant OpenAI per generar una resposta. No incloguis contrasenyes, dades de targetes, números de DNI/passaport ni altra informació sensible.',
      error: 'Ara mateix no puc respondre. Contacta directament amb RSB.',
      thinking: 'Consultant la informació de RSB...',
      chips: ['Preus de lloguer', 'Horaris', 'Documentació', 'On és RSB?']
    },
    sv: {
      open: 'Fråga RSB',
      title: 'RSB AI-assistent',
      intro: 'Fråga om RSB:s uthyrning, priser, öppettider, dokument, utrustning eller plats.',
      placeholder: 'Skriv en fråga...',
      send: 'Skicka',
      close: 'Stäng',
      contact: 'Kontakta RSB',
      notice: 'AI-assistent. Meddelanden behandlas av OpenAI för att skapa ett svar. Ange inte lösenord, kortuppgifter, ID-/passnummer eller annan känslig information.',
      error: 'Jag kan inte svara just nu. Kontakta RSB direkt.',
      thinking: 'Kontrollerar RSB-information...',
      chips: ['Hyrespriser', 'Öppettider', 'Dokument', 'Var ligger RSB?']
    },
    pl: {
      open: 'Zapytaj RSB',
      title: 'Asystent AI RSB',
      intro: 'Zapytaj o wynajem RSB, ceny, godziny otwarcia, dokumenty, wyposażenie lub lokalizację.',
      placeholder: 'Zadaj pytanie...',
      send: 'Wyślij',
      close: 'Zamknij',
      contact: 'Kontakt z RSB',
      notice: 'Asystent AI. Wiadomości są przetwarzane przez OpenAI w celu wygenerowania odpowiedzi. Nie podawaj haseł, danych kart, numerów dokumentów/paszportu ani innych danych wrażliwych.',
      error: 'Nie mogę teraz odpowiedzieć. Skontaktuj się bezpośrednio z RSB.',
      thinking: 'Sprawdzam informacje RSB...',
      chips: ['Ceny wynajmu', 'Godziny otwarcia', 'Wymagane dokumenty', 'Gdzie jest RSB?']
    }
  };

  const rawLang = (document.documentElement.lang || 'en').toLowerCase();
  let lang = rawLang.startsWith('ca') ? 'ca' : rawLang.slice(0, 2);
  if (!I18N[lang]) lang = 'en';
  const t = I18N[lang];

  const contactPaths = {
    en: '/location-contact/',
    es: '/es/location-contact/',
    fr: '/fr/location-contact/',
    it: '/it/location-contact/',
    de: '/de/location-contact/',
    nl: '/nl/location-contact/',
    pt: '/pt/location-contact/',
    ca: '/cat/location-contact/',
    sv: '/sv/location-contact/',
    pl: '/pl/location-contact/'
  };

  const style = document.createElement('style');
  style.id = 'rsb-ai-chat-styles';
  style.textContent = `
    #rsb-ai-launcher{position:fixed;right:18px;bottom:18px;z-index:10020;border:0;border-radius:999px;background:#111827;color:#fff;padding:13px 17px;font:700 14px/1 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;box-shadow:0 8px 28px rgba(0,0,0,.24);cursor:pointer;display:flex;align-items:center;gap:8px}
    #rsb-ai-launcher:hover{transform:translateY(-1px)}
    #rsb-ai-launcher:focus-visible,.rsb-ai-btn:focus-visible,#rsb-ai-input:focus-visible{outline:3px solid #60a5fa;outline-offset:2px}
    #rsb-ai-dot{display:grid;place-items:center;width:27px;height:27px;border-radius:50%;background:#fff;color:#111827;font-size:11px;font-weight:900}
    #rsb-ai-panel{position:fixed;right:18px;bottom:76px;z-index:10019;width:min(390px,calc(100vw - 24px));height:min(610px,calc(100dvh - 105px));background:#fff;color:#111827;border:1px solid #d1d5db;border-radius:20px;box-shadow:0 22px 60px rgba(0,0,0,.24);display:none;overflow:hidden;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
    #rsb-ai-panel[data-open="1"]{display:flex;flex-direction:column}
    #rsb-ai-head{display:flex;align-items:center;justify-content:space-between;padding:14px 16px;background:#111827;color:#fff}
    #rsb-ai-head strong{font-size:15px}
    #rsb-ai-close{border:0;background:transparent;color:#fff;font-size:25px;line-height:1;cursor:pointer;padding:2px 6px}
    #rsb-ai-notice{font-size:11px;line-height:1.35;background:#f3f4f6;color:#4b5563;padding:9px 12px;border-bottom:1px solid #e5e7eb}
    #rsb-ai-messages{flex:1;overflow:auto;padding:13px;overscroll-behavior:contain}
    .rsb-ai-msg{max-width:88%;margin:0 0 10px;padding:10px 12px;border-radius:14px;font-size:14px;line-height:1.45;white-space:pre-wrap;overflow-wrap:anywhere}
    .rsb-ai-assistant{background:#f3f4f6;color:#111827;border-bottom-left-radius:4px}
    .rsb-ai-user{margin-left:auto;background:#111827;color:#fff;border-bottom-right-radius:4px}
    .rsb-ai-thinking{opacity:.7;font-style:italic}
    #rsb-ai-chips{display:flex;gap:6px;overflow-x:auto;padding:0 12px 9px}
    .rsb-ai-chip{flex:0 0 auto;border:1px solid #d1d5db;background:#fff;color:#111827;border-radius:999px;padding:7px 10px;font-size:12px;cursor:pointer}
    #rsb-ai-form{display:flex;gap:7px;padding:10px;border-top:1px solid #e5e7eb;background:#fff}
    #rsb-ai-input{flex:1;min-width:0;border:1px solid #cbd5e1;border-radius:12px;padding:10px 11px;font:14px system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
    .rsb-ai-btn{border:0;background:#111827;color:#fff;border-radius:12px;padding:0 14px;font-weight:700;cursor:pointer}
    .rsb-ai-btn:disabled{opacity:.5;cursor:not-allowed}
    #rsb-ai-contact{display:block;margin:0 12px 10px;text-align:center;color:#334155;font-size:12px;text-decoration:underline}
    @media(max-width:600px){
      #rsb-ai-launcher{right:12px;bottom:max(12px,env(safe-area-inset-bottom));padding:12px 14px}
      #rsb-ai-panel{right:12px;bottom:72px;width:calc(100vw - 24px);height:min(640px,calc(100dvh - 92px));border-radius:18px}
    }
    @media(prefers-reduced-motion:reduce){#rsb-ai-launcher{transition:none}}
  `;
  document.head.appendChild(style);

  const launcher = document.createElement('button');
  launcher.id = 'rsb-ai-launcher';
  launcher.type = 'button';
  launcher.setAttribute('aria-expanded', 'false');
  launcher.setAttribute('aria-controls', 'rsb-ai-panel');
  launcher.setAttribute('aria-label', t.open);

  const dot = document.createElement('span');
  dot.id = 'rsb-ai-dot';
  dot.textContent = 'AI';

  const launcherText = document.createElement('span');
  launcherText.textContent = t.open;

  launcher.append(dot, launcherText);

  const panel = document.createElement('section');
  panel.id = 'rsb-ai-panel';
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-label', t.title);
  panel.setAttribute('aria-modal', 'false');

  const head = document.createElement('div');
  head.id = 'rsb-ai-head';

  const title = document.createElement('strong');
  title.textContent = t.title;

  const close = document.createElement('button');
  close.id = 'rsb-ai-close';
  close.type = 'button';
  close.setAttribute('aria-label', t.close);
  close.textContent = '×';

  head.append(title, close);

  const notice = document.createElement('div');
  notice.id = 'rsb-ai-notice';
  notice.textContent = t.notice;

  const messages = document.createElement('div');
  messages.id = 'rsb-ai-messages';
  messages.setAttribute('aria-live', 'polite');

  const chips = document.createElement('div');
  chips.id = 'rsb-ai-chips';

  const form = document.createElement('form');
  form.id = 'rsb-ai-form';

  const input = document.createElement('input');
  input.id = 'rsb-ai-input';
  input.type = 'text';
  input.maxLength = 600;
  input.autocomplete = 'off';
  input.placeholder = t.placeholder;
  input.setAttribute('aria-label', t.placeholder);

  const send = document.createElement('button');
  send.className = 'rsb-ai-btn';
  send.type = 'submit';
  send.textContent = t.send;

  form.append(input, send);

  const contact = document.createElement('a');
  contact.id = 'rsb-ai-contact';
  contact.href = contactPaths[lang] || contactPaths.en;
  contact.textContent = t.contact;

  panel.append(head, notice, messages, chips, form, contact);
  document.body.append(panel, launcher);

  const history = [];
  let busy = false;

  function addMessage(text, who, extraClass='') {
    const el = document.createElement('div');
    el.className = `rsb-ai-msg rsb-ai-${who}${extraClass ? ' '+extraClass : ''}`;
    el.textContent = text;
    messages.appendChild(el);
    messages.scrollTop = messages.scrollHeight;
    return el;
  }

  addMessage(t.intro, 'assistant');

  t.chips.forEach(label => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'rsb-ai-chip';
    b.textContent = label;
    b.addEventListener('click', () => ask(label));
    chips.appendChild(b);
  });

  function setOpen(open) {
    panel.dataset.open = open ? '1' : '0';
    launcher.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (open) setTimeout(() => input.focus(), 0);
  }

  launcher.addEventListener('click', () => {
    setOpen(panel.dataset.open !== '1');
  });

  close.addEventListener('click', () => {
    setOpen(false);
    launcher.focus();
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && panel.dataset.open === '1') {
      setOpen(false);
      launcher.focus();
    }
  });

  async function ask(raw) {
    const text = String(raw || '').trim();
    if (!text || busy || text.length > 600) return;

    const prior = history.slice(-6);
    addMessage(text, 'user');
    history.push({role:'user', text});
    input.value = '';

    busy = true;
    send.disabled = true;
    input.disabled = true;
    const thinking = addMessage(t.thinking, 'assistant', 'rsb-ai-thinking');

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 25000);

    try {
      const res = await fetch('/api/ai-chat.php', {
        method: 'POST',
        headers: {'Content-Type':'application/json','Accept':'application/json'},
        credentials: 'same-origin',
        signal: controller.signal,
        body: JSON.stringify({
          message: text,
          history: prior,
          lang,
          page: location.pathname,
          website: ''
        })
      });

      const data = await res.json().catch(() => null);
      thinking.remove();

      if (!res.ok || !data || data.ok !== true || typeof data.answer !== 'string') {
        throw new Error('AI_RESPONSE_ERROR');
      }

      const answer = data.answer.trim();
      addMessage(answer || t.error, 'assistant');
      history.push({role:'assistant', text: answer || t.error});
    } catch (_) {
      if (thinking.isConnected) thinking.remove();
      addMessage(t.error, 'assistant');
    } finally {
      clearTimeout(timer);
      busy = false;
      send.disabled = false;
      input.disabled = false;
      input.focus();
    }
  }

  form.addEventListener('submit', e => {
    e.preventDefault();
    ask(input.value);
  });
})();
